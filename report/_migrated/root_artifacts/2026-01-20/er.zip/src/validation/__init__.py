"""Validation package compatibility layer."""

