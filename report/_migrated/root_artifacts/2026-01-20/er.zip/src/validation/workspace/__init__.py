"""Workspace compatibility package."""

