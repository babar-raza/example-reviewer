"""
Compilation Service for Example Reviewer Pipeline.
Implements Phase B: Compilation Verification Loop.
"""

import os
import re
import uuid
import json
import shutil
import logging
import tempfile
import subprocess
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass

from ..core.models import (
    ExampleRecord, ExampleStatus, CompileAttempt, LLMFixPayload
)
from ..core.database import Database
from ..core.config import FamilyConfig

logger = logging.getLogger(__name__)


@dataclass
class CompileResult:
    """Result of a compilation attempt."""
    success: bool
    exit_code: int
    stdout: str
    stderr: str
    duration_ms: int
    dll_version: str
    errors: List[str]
    warnings: List[str]


class CompilationService:
    """
    Service for compiling and validating C# code examples.
    Implements the B_compile_verify_fix_loop phase from the spec.
    """

    # Default using statements for common scenarios
    DEFAULT_USINGS = [
        "System",
        "System.IO",
        "System.Text",
        "System.Linq",
        "System.Collections.Generic",
        "System.Threading.Tasks",
    ]

    # API class to namespace mapping for intelligent using inference
    API_NAMESPACE_MAP = {
        # Aspose.Zip
        'Archive': 'Aspose.Zip',
        'ArchiveEntry': 'Aspose.Zip',
        'ArchiveFactory': 'Aspose.Zip',
        'ArchiveEntrySettings': 'Aspose.Zip.Saving',
        'CompressionSettings': 'Aspose.Zip.Saving',
        'DeflateCompressionSettings': 'Aspose.Zip.Saving',
        'Bzip2CompressionSettings': 'Aspose.Zip.Saving',
        'LzmaCompressionSettings': 'Aspose.Zip.Saving',
        'ParallelCompressionOptions': 'Aspose.Zip.Saving',
        'SevenZipArchive': 'Aspose.Zip.SevenZip',
        'SevenZipArchiveEntry': 'Aspose.Zip.SevenZip',
        'SevenZipCompressionSettings': 'Aspose.Zip.Saving',
        'RarArchive': 'Aspose.Zip.Rar',
        'RarArchiveEntry': 'Aspose.Zip.Rar',
        'TarArchive': 'Aspose.Zip.Tar',
        'GzipArchive': 'Aspose.Zip.Gzip',
        'CabArchive': 'Aspose.Zip.Cab',
        'WimArchive': 'Aspose.Zip.Wim',
        'XarArchive': 'Aspose.Zip.Xar',
        'CpioArchive': 'Aspose.Zip.Cpio',
    }

    # Error pattern recognition for targeted fixes
    ERROR_PATTERNS = {
        r"CS0246.*type.*'(\w+)'": "missing_type",  # Matches "could not be found" or "not found"
        r"CS0103.*name.*'(\w+)'": "undefined_variable",  # Matches various phrasings
        r"CS1002.*;.*expected": "missing_semicolon",
        r"CS1513.*}.*expected": "missing_brace",
        r"CS0029.*Cannot.*convert": "type_mismatch",
        r"CS0117.*does not contain": "member_not_found",
        r"CS1061.*does not contain.*definition": "member_not_found",
        r"CS0246.*namespace": "missing_namespace",
        r"CS8803.*Top-level statements": "top_level_statements_error",
    }
    
    # Project template for .NET 8
    PROJECT_TEMPLATE = """<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <OutputType>Exe</OutputType>
  </PropertyGroup>
  <ItemGroup>
{package_refs}
  </ItemGroup>
</Project>
"""
    
    def __init__(
        self,
        db: Database,
        workspace_dir: Optional[Path] = None,
        artifacts_dir: Optional[Path] = None,
    ):
        """
        Initialize compilation service.
        
        Args:
            db: Database instance
            workspace_dir: Working directory for compilation
            artifacts_dir: Directory for storing compilation artifacts
        """
        self.db = db
        self.workspace_dir = workspace_dir or Path(tempfile.gettempdir()) / "example_reviewer"
        self.artifacts_dir = artifacts_dir or self.workspace_dir / "artifacts"
        
        self.workspace_dir.mkdir(parents=True, exist_ok=True)
        self.artifacts_dir.mkdir(parents=True, exist_ok=True)
    
    def compile_example(
        self,
        example: ExampleRecord,
        family_config: FamilyConfig,
    ) -> Tuple[bool, CompileResult]:
        """
        Attempt to compile a single example.
        
        Args:
            example: Example record to compile
            family_config: Family configuration
            
        Returns:
            Tuple of (success, CompileResult)
        """
        # Create workspace for this compilation
        work_dir = self.workspace_dir / f"compile_{example.example_id}"
        
        try:
            if work_dir.exists():
                shutil.rmtree(work_dir)
            work_dir.mkdir(parents=True)
            
            # Get code to compile (use compilable_code if available, else original)
            code = example.compilable_code or example.original_code
            
            # Wrap code in compilable structure
            wrapped_code = self._wrap_code(code, family_config)
            
            # Write project files
            self._write_project(work_dir, family_config)
            
            # Write code file
            code_path = work_dir / "Program.cs"
            code_path.write_text(wrapped_code, encoding='utf-8')
            
            # Run dotnet build
            result = self._run_build(work_dir, family_config)
            
            return result.success, result
            
        finally:
            # Cleanup workspace
            if work_dir.exists():
                try:
                    shutil.rmtree(work_dir)
                except Exception:
                    pass
    
    def _analyze_code(self, code: str, family_config: FamilyConfig) -> Dict[str, Any]:
        """
        Analyze code to determine its structure and what's missing.

        Returns:
            Dictionary with analysis results including detected APIs and missing elements
        """
        # Check for various code elements
        has_usings = bool(re.search(r'^\s*using\s+[\w\.]+\s*;', code, re.MULTILINE))
        has_namespace = bool(re.search(r'\bnamespace\s+[\w\.]+', code))
        has_class = bool(re.search(r'\bclass\s+\w+', code))
        has_main = bool(re.search(r'\bstatic\s+(?:async\s+)?(?:void|Task|Task<int>|int)\s+Main\s*\(', code))
        is_async = bool(re.search(r'\bawait\s+', code)) or bool(re.search(r'\basync\s+', code))

        # Detect API usage by looking for class instantiations and references
        detected_apis = []
        for api_class in self.API_NAMESPACE_MAP.keys():
            # Look for: new ApiClass, ApiClass., ApiClass<, or just ApiClass as a type
            patterns = [
                rf'\bnew\s+{api_class}\b',
                rf'\b{api_class}\.',
                rf'\b{api_class}<',
                rf'<{api_class}>',
                rf'\({api_class}\s+\w+\)',  # Parameter: (ApiClass param)
            ]
            if any(re.search(pattern, code) for pattern in patterns):
                detected_apis.append(api_class)

        # Infer missing using statements
        missing_usings = self._infer_usings(code, family_config, detected_apis)

        # Check if code is complete (has all necessary structure)
        is_complete = has_namespace or (has_class and has_main)

        return {
            'has_usings': has_usings,
            'has_namespace': has_namespace,
            'has_class': has_class,
            'has_main': has_main,
            'is_async': is_async,
            'detected_apis': detected_apis,
            'missing_usings': missing_usings,
            'is_complete': is_complete,
        }

    def _infer_usings(self, code: str, family_config: FamilyConfig, detected_apis: List[str]) -> List[str]:
        """
        Infer required using statements from API usage in code.

        Args:
            code: Code to analyze
            family_config: Family configuration
            detected_apis: List of detected API classes

        Returns:
            List of required using statements
        """
        required_usings = set(self.DEFAULT_USINGS)

        # Add family-specific usings
        if family_config.code_defaults:
            required_usings.update(family_config.code_defaults.default_usings)

        # Add usings based on detected APIs
        for api_class in detected_apis:
            if api_class in self.API_NAMESPACE_MAP:
                namespace = self.API_NAMESPACE_MAP[api_class]
                required_usings.add(namespace)

        # Extract existing using statements
        existing_usings = set()
        using_pattern = r'using\s+([\w\.]+)\s*;'
        for match in re.finditer(using_pattern, code):
            existing_usings.add(match.group(1))

        # Return only missing usings
        missing = required_usings - existing_usings
        return sorted(list(missing))

    def _wrap_code(self, code: str, family_config: FamilyConfig) -> str:
        """
        Intelligently wrap code snippet in a compilable structure based on what's already present.

        Detection rules:
        - Has 'namespace' -> wrap minimally, just add missing usings
        - Has 'class' but no namespace -> add namespace and usings
        - Has 'Main' method -> add class wrapper and usings
        - Raw statements -> full wrapper (usings + class + Main)

        Also handles:
        - Top-level statements (C# 9+)
        - Async Main patterns
        - Multiple class definitions
        - Partial code snippets

        Args:
            code: Original code snippet
            family_config: Family configuration

        Returns:
            Wrapped code ready for compilation
        """
        # Analyze the code
        analysis = self._analyze_code(code, family_config)

        lines = []

        # Strategy 1: Code has namespace - minimal wrapping needed
        if analysis['has_namespace']:
            # Just add missing usings at the top if needed
            if analysis['missing_usings']:
                for using in analysis['missing_usings']:
                    lines.append(f"using {using};")
                lines.append("")
            lines.append(code)
            return '\n'.join(lines)

        # Strategy 2: Code has class but no namespace
        if analysis['has_class']:
            # Add usings
            all_usings = list(set(self.DEFAULT_USINGS + (family_config.code_defaults.default_usings if family_config.code_defaults else [])))
            if analysis['detected_apis']:
                for api in analysis['detected_apis']:
                    if api in self.API_NAMESPACE_MAP:
                        all_usings.append(self.API_NAMESPACE_MAP[api])

            if not analysis['has_usings']:
                for using in sorted(set(all_usings)):
                    lines.append(f"using {using};")
                lines.append("")

            lines.append(code)
            return '\n'.join(lines)

        # Strategy 3: Code has Main method but no class - just add class wrapper
        if analysis['has_main']:
            # Add usings
            if analysis['missing_usings']:
                for using in analysis['missing_usings']:
                    lines.append(f"using {using};")
                lines.append("")

            lines.append("public class Program")
            lines.append("{")
            # Indent existing code
            for line in code.split('\n'):
                lines.append(f"    {line}")
            lines.append("}")
            return '\n'.join(lines)

        # Strategy 4: Raw statements - full wrapper needed
        # Separate using statements from actual code
        code_lines = code.split('\n')
        using_lines = []
        code_body_lines = []
        in_usings = True

        for line in code_lines:
            stripped = line.strip()
            # Check if this line is a using statement
            if in_usings and (stripped.startswith('using ') and stripped.endswith(';')):
                using_lines.append(line)
            elif in_usings and (not stripped or stripped.startswith('//')):
                # Skip empty lines and comments at the top
                continue
            else:
                # Once we hit non-using code, add all remaining lines to body
                in_usings = False
                code_body_lines.append(line)

        # Add all required usings (combine with existing)
        all_usings = set(self.DEFAULT_USINGS)
        if family_config.code_defaults:
            all_usings.update(family_config.code_defaults.default_usings)
        for api in analysis['detected_apis']:
            if api in self.API_NAMESPACE_MAP:
                all_usings.add(self.API_NAMESPACE_MAP[api])

        # Extract namespaces from existing using statements
        for using_line in using_lines:
            match = re.match(r'using\s+([\w\.]+)\s*;', using_line.strip())
            if match:
                all_usings.add(match.group(1))

        # Write all usings
        for using in sorted(all_usings):
            lines.append(f"using {using};")
        lines.append("")

        lines.append("public class Program")
        lines.append("{")

        # Determine Main signature
        if analysis['is_async']:
            lines.append("    public static async Task Main(string[] args)")
        else:
            lines.append("    public static void Main(string[] args)")

        lines.append("    {")

        # Indent only the actual code body (not the using statements)
        for line in code_body_lines:
            lines.append(f"        {line}")

        lines.append("    }")
        lines.append("}")

        return '\n'.join(lines)
    
    def _write_project(self, work_dir: Path, family_config: FamilyConfig) -> None:
        """Write .csproj file for compilation."""
        nuget_config = family_config.nuget_config
        
        # Build package references
        package_refs = []
        
        if nuget_config:
            # Primary package
            primary = nuget_config.primary_package
            if primary and primary.name:
                version = primary.version if primary.version else "*"
                package_refs.append(
                    f'    <PackageReference Include="{primary.name}" Version="{version}" />'
                )
            
            # Additional packages
            for pkg in nuget_config.additional_packages:
                if pkg.name:
                    version = pkg.version if pkg.version else "*"
                    package_refs.append(
                        f'    <PackageReference Include="{pkg.name}" Version="{version}" />'
                    )
        
        # Write project file
        project_content = self.PROJECT_TEMPLATE.format(
            package_refs='\n'.join(package_refs)
        )
        
        (work_dir / "Compilation.csproj").write_text(project_content, encoding='utf-8')
    
    def _run_build(self, work_dir: Path, family_config: FamilyConfig) -> CompileResult:
        """Run dotnet build and collect results."""
        import time
        
        start_time = time.time()
        
        try:
            # Restore packages first
            restore_result = subprocess.run(
                ["dotnet", "restore", "--verbosity", "minimal"],
                cwd=work_dir,
                capture_output=True,
                text=True,
                timeout=120,  # Longer timeout for restore
            )
            
            # Check if restore failed
            if restore_result.returncode != 0:
                duration_ms = int((time.time() - start_time) * 1000)
                combined_output = restore_result.stdout + restore_result.stderr
                return CompileResult(
                    success=False,
                    exit_code=restore_result.returncode,
                    stdout=restore_result.stdout,
                    stderr=restore_result.stderr,
                    duration_ms=duration_ms,
                    dll_version="unknown",
                    errors=self._parse_errors(combined_output) or ["Package restore failed"],
                    warnings=self._parse_warnings(combined_output),
                )
            
            # Build (no-restore since we just restored)
            build_result = subprocess.run(
                ["dotnet", "build", "--no-restore", "--verbosity", "minimal"],
                cwd=work_dir,
                capture_output=True,
                text=True,
                timeout=120,
            )
            
            duration_ms = int((time.time() - start_time) * 1000)
            
            # Parse errors and warnings
            combined_output = build_result.stdout + build_result.stderr
            errors = self._parse_errors(combined_output)
            warnings = self._parse_warnings(combined_output)
            
            # Get DLL version from nuget config
            dll_version = "latest"
            if family_config.nuget_config and family_config.nuget_config.primary_package:
                dll_version = family_config.nuget_config.primary_package.version or "latest"
            
            return CompileResult(
                success=build_result.returncode == 0,
                exit_code=build_result.returncode,
                stdout=build_result.stdout,
                stderr=build_result.stderr,
                duration_ms=duration_ms,
                dll_version=dll_version,
                errors=errors,
                warnings=warnings,
            )
            
        except subprocess.TimeoutExpired:
            duration_ms = int((time.time() - start_time) * 1000)
            return CompileResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr="Compilation timed out",
                duration_ms=duration_ms,
                dll_version="unknown",
                errors=["Compilation timed out"],
                warnings=[],
            )
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            return CompileResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr=str(e),
                duration_ms=duration_ms,
                dll_version="unknown",
                errors=[str(e)],
                warnings=[],
            )
    
    def _parse_errors(self, output: str) -> List[str]:
        """Parse compilation errors from output."""
        errors = []
        for line in output.split('\n'):
            if ': error ' in line or 'error CS' in line:
                errors.append(line.strip())
        return errors
    
    def _parse_warnings(self, output: str) -> List[str]:
        """Parse compilation warnings from output."""
        warnings = []
        for line in output.split('\n'):
            if ': warning ' in line or 'warning CS' in line:
                warnings.append(line.strip())
        return warnings

    def categorize_errors(self, errors: List[str]) -> Dict[str, List[str]]:
        """
        Categorize compilation errors for targeted fixes.

        Args:
            errors: List of error messages

        Returns:
            Dictionary mapping error categories to specific errors
        """
        categorized = {}

        for error in errors:
            categorized_flag = False
            for pattern, category in self.ERROR_PATTERNS.items():
                if re.search(pattern, error, re.IGNORECASE):
                    if category not in categorized:
                        categorized[category] = []
                    categorized[category].append(error)
                    categorized_flag = True
                    break

            # Uncategorized errors
            if not categorized_flag:
                if 'unknown' not in categorized:
                    categorized['unknown'] = []
                categorized['unknown'].append(error)

        return categorized

    def get_error_fix_hints(self, error_categories: Dict[str, List[str]], family_config: FamilyConfig) -> List[str]:
        """
        Get fix hints based on error categories.

        Args:
            error_categories: Categorized errors
            family_config: Family configuration

        Returns:
            List of fix hints
        """
        hints = []

        if 'missing_type' in error_categories:
            # Extract missing types
            missing_types = []
            for error in error_categories['missing_type']:
                match = re.search(r"type.*'(\w+)'", error)
                if match:
                    missing_types.append(match.group(1))

            # Suggest namespaces
            suggested_namespaces = set()
            for missing_type in missing_types:
                if missing_type in self.API_NAMESPACE_MAP:
                    suggested_namespaces.add(self.API_NAMESPACE_MAP[missing_type])

            if suggested_namespaces:
                hints.append(f"Add using statements: {', '.join(sorted(suggested_namespaces))}")

        if 'undefined_variable' in error_categories:
            hints.append("Declare variables before use or check for typos")

        if 'missing_semicolon' in error_categories:
            hints.append("Add missing semicolons")

        if 'missing_brace' in error_categories:
            hints.append("Check for missing closing braces")

        if 'type_mismatch' in error_categories:
            hints.append("Use explicit type casting or correct types")

        if 'top_level_statements_error' in error_categories:
            hints.append("Wrap code in class and Main method - top-level statements must come before other declarations")

        return hints
    
    def create_fix_payload(
        self,
        example: ExampleRecord,
        compile_result: CompileResult,
        family_config: Optional[FamilyConfig] = None,
        api_context: Optional[str] = None,
        similar_examples: Optional[List[str]] = None,
    ) -> LLMFixPayload:
        """
        Create payload for LLM-based code fixing with enhanced context.

        Args:
            example: Example that failed compilation
            compile_result: Compilation result with errors
            family_config: Family configuration
            api_context: Relevant API documentation
            similar_examples: Similar working examples

        Returns:
            LLMFixPayload for sending to LLM
        """
        # Combine error information
        errors = compile_result.errors + [
            f"Exit code: {compile_result.exit_code}",
            compile_result.stderr,
        ]

        default_usings = []
        nuget_package = ""
        scaffolding_hints = []

        if family_config:
            if family_config.code_defaults:
                default_usings = family_config.code_defaults.default_usings
            if family_config.nuget_config and family_config.nuget_config.primary_package:
                nuget_package = family_config.nuget_config.primary_package.name

            # Categorize errors and generate hints
            error_categories = self.categorize_errors(compile_result.errors)
            fix_hints = self.get_error_fix_hints(error_categories, family_config)
            scaffolding_hints.extend(fix_hints)

            # Log error categories for debugging
            if error_categories:
                logger.info(f"Error categories for {example.example_id}: {list(error_categories.keys())}")

        return LLMFixPayload(
            code=example.compilable_code or example.original_code,
            errors=errors,
            context_type="compile",
            api_references=[api_context] if api_context else [],
            similar_examples=similar_examples or [],
            scaffolding_hints=scaffolding_hints,
            family=example.family,
            nuget_package=nuget_package,
            default_usings=default_usings,
        )
    
    def record_attempt(
        self,
        example_id: str,
        compile_result: CompileResult,
        input_code: str,
        output_code: Optional[str] = None,
        llm_request: Optional[str] = None,
        llm_response: Optional[str] = None,
    ) -> str:
        """
        Record a compilation attempt in the database.
        
        Args:
            example_id: Example ID
            compile_result: Compilation result
            input_code: Code that was compiled
            output_code: Fixed code (if any)
            llm_request: LLM request (if applicable)
            llm_response: LLM response (if applicable)
            
        Returns:
            Attempt ID
        """
        attempt_id = str(uuid.uuid4())[:8]
        
        # Store artifacts
        input_ref = self._store_artifact(f"{attempt_id}_input.cs", input_code)
        output_ref = None
        if output_code:
            output_ref = self._store_artifact(f"{attempt_id}_output.cs", output_code)
        
        log_ref = self._store_artifact(
            f"{attempt_id}_log.txt",
            f"{compile_result.stdout}\n{compile_result.stderr}"
        )
        
        llm_req_ref = None
        llm_resp_ref = None
        if llm_request:
            llm_req_ref = self._store_artifact(f"{attempt_id}_llm_req.txt", llm_request)
        if llm_response:
            llm_resp_ref = self._store_artifact(f"{attempt_id}_llm_resp.txt", llm_response)
        
        attempt = CompileAttempt(
            attempt_id=attempt_id,
            example_id=example_id,
            family=self.db.get_example(example_id).family if self.db.get_example(example_id) else "",
            dll_version=compile_result.dll_version,
            success=compile_result.success,
            compiler_log_ref=log_ref,
            input_code_ref=input_ref,
            output_code_ref=output_ref or "",
            llm_request_ref=llm_req_ref or "",
            llm_response_ref=llm_resp_ref or "",
            error_messages=compile_result.errors,
            warnings=compile_result.warnings,
        )
        
        self.db.save_compile_attempt(attempt)
        return attempt_id
    
    def _store_artifact(self, filename: str, content: str) -> str:
        """Store an artifact file and return its reference."""
        artifact_path = self.artifacts_dir / filename
        artifact_path.write_text(content, encoding='utf-8')
        return str(artifact_path)


def check_dotnet_available() -> Tuple[bool, str]:
    """Check if .NET SDK is available."""
    try:
        result = subprocess.run(
            ["dotnet", "--version"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            return True, result.stdout.strip()
        return False, result.stderr
    except Exception as e:
        return False, str(e)
