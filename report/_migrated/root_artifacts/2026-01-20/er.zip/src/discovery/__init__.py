"""Discovery compatibility package."""

